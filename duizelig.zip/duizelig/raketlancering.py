import time

i = 30
while i >= 0:
    print(i)
    i = i - 1
    time.sleep(1)

print("Lanceering")
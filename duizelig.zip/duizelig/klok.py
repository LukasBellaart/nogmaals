i = 1
x = 1
while i <= 12:
    print(str(i) + "AM")
    i = i + 1

while x <= 12:
    print(str(x)+"PM")
    x = x + 1
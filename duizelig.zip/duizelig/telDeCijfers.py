i = 50
x = 0
while x <= 1000:
    x = x + i
    i = i + 1
    print(x)
    print(i)